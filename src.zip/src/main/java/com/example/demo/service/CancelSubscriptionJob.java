package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.example.demo.repo.CustomerDetailsRepo;

@Component
public class CancelSubscriptionJob {

    @Autowired
    private CustomerDetailsRepo customerDetailsRepo;

    @Scheduled(cron = "0 59 23 * * ?")
    public void cancelSubscriptions() {

        int updated = customerDetailsRepo.cancelExpiredSubscriptions();

        System.out.println("Cancelled subscriptions: " + updated);
    }
}